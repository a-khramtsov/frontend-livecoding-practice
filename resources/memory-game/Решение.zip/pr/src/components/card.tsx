import styled from "styled-components";

type Props = {
  symbol: string;
  active: boolean;
  onClick: VoidFunction;
  id: number;
};

export default function Card(props: Props) {
  const { symbol, active, onClick, id } = props;

  return (
    <S.Card data-id={id} onClick={onClick}>{active ? symbol : null}</S.Card>
  );
}

const S = {
  Card: styled.div`
    height: 100px;
    width: 75px;
    border-radius: 12px;
    border-width: 3px;
    border-style: solid;
    font-size: 24px;
    border-color: violet;
    background-color: #fff;
  `,
};

