import React, { useCallback, useMemo, useState, useRef, useEffect } from "react";
import * as S from "./styles/global";
import Card from "./components/card";
import { symbols } from "./lib/cards"
import { v4 as uuidv4 } from 'uuid';

function randomIntFromInterval(min: number, max: number) { // min and max included 
  return Math.floor(Math.random() * (max - min + 1) + min);
}


type TCard = {
  readonly id: number;
  symbol: string;
}


const useCards = () => {
  const [cards, setCards] = useState<TCard[]>([])

  const generateCards = useCallback(() => {
    const cardsSymbols = [];

    const MAX_SYMBOL_CARD_AMOUNT = 2;
    const CARDS_COUNT = symbols.length * MAX_SYMBOL_CARD_AMOUNT;

    const existStorage: Record<string, number> = {};

    let correctSymbolIndex = 0;
    while (correctSymbolIndex < CARDS_COUNT) {
      const randomIndex = randomIntFromInterval(0, symbols.length - 1);
      const symbol = symbols[randomIndex];

      if (!existStorage[symbol]) {
        existStorage[symbol] = 0;
      }

      if (existStorage[symbol] < 2) {
        cardsSymbols.push({ id: uuidv4(), symbol });
        existStorage[symbol]++;
        correctSymbolIndex++;
      }
    }

    setCards(cardsSymbols);
  }, [])

  return {
    cards,
    generateCards,
  };
}

const useGamePreparation = ({ cards, setCorrectIDs }: { cards: TCard[], setCorrectIDs: (ids: Set<number>) => void }) => {
  useEffect(() => {
    const ids = cards.map(card => card.id);
    setCorrectIDs(new Set(ids));

    setTimeout(() => {
      setCorrectIDs(new Set());
    }, 3000)
  }, [cards]) 

}

const useGame = () => {
  const currentCardID = useRef<number | null>(null);
  const [correctCardsIDs, setCorrectIDs] = useState<Set<number>>(new Set());
  const [isCurrentPairVisible, setIsCurrentPairVisible] = useState(false);
  
  const { cards, generateCards } = useCards();
  useGamePreparation({ cards, setCorrectIDs });

  const restartGame = useCallback(() => {
    setCorrectIDs(new Set());
    setIsCurrentPairVisible(false)
    currentCardID.current = null;
    generateCards();
  }, [])

  const handleCardClick = useCallback((idByIdex: number) => {
    if (isCurrentPairVisible) {
      return;
    }


    if (!currentCardID?.current) {
      currentCardID.current = idByIdex;

      const newSet = new Set(correctCardsIDs);
      newSet.add(idByIdex);
      setCorrectIDs(newSet);

      return;
    }

    const indexByPreviousId = cards.findIndex((el) => el.id === currentCardID?.current);
    const indexByCurrentId = cards.findIndex((el) => el.id === idByIdex);

    const symbol1 = cards[indexByPreviousId].symbol;
    const symbol2 = cards[indexByCurrentId].symbol;


    if (currentCardID?.current) {
      const newSet = new Set(correctCardsIDs);
      newSet.add(idByIdex);
      newSet.add(currentCardID.current!);

      setCorrectIDs(newSet);
    }

    if (symbol1 !== symbol2) {
      setTimeout(() => {
        const newSet = new Set(correctCardsIDs);
        newSet.delete(idByIdex);
        newSet.delete(currentCardID.current!);
  
        setCorrectIDs(newSet);
        setIsCurrentPairVisible(false);
        
        currentCardID.current = null;
      }, 3000)
      setIsCurrentPairVisible(true);
    } else {
      currentCardID.current = null;
    }
  }, [isCurrentPairVisible, setIsCurrentPairVisible, cards, correctCardsIDs])

  return {
    cards,
    correctCardsIDs,
    chooseCard: handleCardClick,
    restartGame
  }
}

export default function Game() {
  const { cards, correctCardsIDs, chooseCard, restartGame } = useGame();

  useEffect(() => {
    restartGame();
  }, [])

  return (
    <>
      <S.CardContainer>
        {cards.map((card) => (
          <Card 
            id={card.id}
            key={card.id} 
            symbol={card.symbol} 
            active={correctCardsIDs.has(card.id)}
            onClick={() => chooseCard(card.id)}
          />
        ))}
       
      </S.CardContainer>
      <S.RestartButton onClick={restartGame}>RESTART</S.RestartButton>
    </>
  );
}



