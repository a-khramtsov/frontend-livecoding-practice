import ReactDOM from "react-dom/client";
import { StyleSheetManager } from "styled-components";
import isPropValid from "@emotion/is-prop-valid";
import Game from "./app";
import { GlobalStyle } from "./styles/global";

ReactDOM.createRoot(document.querySelector("#root")).render(
	<StyleSheetManager shouldForwardProp={isPropValid}>
		<GlobalStyle />
		<Game />
	</StyleSheetManager>,
);
