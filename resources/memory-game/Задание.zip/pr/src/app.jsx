import React from "react";
import * as S from "./styles/global";
import Card from "./components/card";
import { symbols } from "./lib/cards.ts"

export default function Game() {
  return (
    <>
      <S.CardContainer>
        <Card symbol={symbols[0]}/>
      </S.CardContainer>
      <S.RestartButton>RESTART</S.RestartButton>
    </>
  );
}
