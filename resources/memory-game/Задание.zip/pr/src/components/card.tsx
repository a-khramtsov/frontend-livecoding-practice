import styled from "styled-components";

type Props = {
  symbol: string;
};

export default function Card({ symbol }: Props) {
  return (
    <S.Card>{symbol}</S.Card>
  );
}

const S = {
  Card: styled.div`
    height: 100px;
    width: 75px;
    border-radius: 12px;
    border-width: 3px;
    border-style: solid;
    font-size: 24px;
    border-color: violet;
    background-color: #fff;
  `,
};
